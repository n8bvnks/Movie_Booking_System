package nz.ac.ara.comp713.booking_service.service;

public class BookingService {
    
}
